<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" type="text/css" href="item.css">
</head>
<body>

<div class="header">
    <h1>EventiN</h1>
    <p>Купете билет за своето любимо събитие онлайн</p>
</div>

<div class="nav">
    <a href="login.php">Вход</a>
    <a href="index.php">Събития</a>
    <a href="contacts.php">Контакти</a>
</div>


<div class="ticket-display">
    <h2>Ticket Information</h2>
    <p>ID for Ticket:</p>
    <h4>№:155</h4>
</div>

</body>
</html>
