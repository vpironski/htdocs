<?php
class IncorrectInformationException extends Exception
{
    public function __construct($message = "Incorrect information provided", $code = 0, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }

    public function __toString()
    {
        return __CLASS__ . ": [{$this->code}]: {$this->message}\n";
    }
}

